This project was done along with Jennifer Rajseharan 

To run the nbtrain.java program please follow below steps(commands)
this program takes 2 parameters (dev or test, �objectfile.txt�)
1) javac nbtrain.java
To run nbtrain:
2) java nbtrain objectfile.txt

Output from training is present in objectfile.txt file. This is object file hence unreadable

To run nbtest: (this program takes 3 parameters)
1) javac nbtest.java
for dev:
2) java nbtest dev objectfile.txt devprediction.txt
for test:
2) java nbtest test objectfile.txt testprediction.txt

The dev and test predictions are found in :

devpredictions and testpredictions

A list of the 20 terms with the highest (log) ratio of positive to negative weight is found in PositiveToNegativeRatio.txt

A list of the 20 terms with the highest (log) ratio of positive to negative weight is found in NegativeToPositiveRatio.txt

When running on dev, the percentage of positive and negative reviews in the development data which were correctly classified:

percentage of positive correctly identified: 73.0%
percentage of negative correctly identified: 84.0%

Extra credit:


The modified code is in modifiedtrain.java and modified test.java. Use the same instructions as above for nbtrain and nbtest to run the modified code.

percentage of positive correctly identified: 86.0%
percentage of negative correctly identified: 81.0%

The test predictions and dev predictions for the modified test and train code is found in: 

modtestpredict and moddevpredict

Changes in training model:

While the training model was specified to use unigrams as a bag of words, during reviews some words do not occur independently, like �don�t like�. So, in the modified train program, we have also included bigrams. We have also changed the bag of words to included only bigrams and unigrams which occur at least 7 times.

Observation for changing features in training model:

One surprising note is that adding bigrams to the bag of words did not increase our accuracy. However, increasing the condition of n-grams to exist atlas 7 times increased the accuracy.

Changes in testing model:

In the test program, we have changed the smoothing to the more general version Laplace smoothing which is Lidstone Smoothing. So the constant a is added to the numerator and is multiplied to the vocabulary.

Observation for changing features in training model:

The change to Lidstone Smoothing increased the accuracy by nearly 5%.
