
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.Character.Subset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class nbtrain {
	static private Map<String, Integer> vocabulary=new LinkedHashMap<String, Integer>();
	static private Map<String, Integer> pos_map=new LinkedHashMap<String, Integer>();
	static private Map<String, Integer> neg_map=new LinkedHashMap<String, Integer>();
	static private Map<String, Integer> pos_map_length=new LinkedHashMap<String, Integer>();
	static private Map<String, Integer> neg_map_length=new LinkedHashMap<String, Integer>();
	
	public static void main(String[] args) {
		File trainFiles = new File(args[0]);
		if(trainFiles.isDirectory()){
			for(File f: trainFiles.listFiles()){
				Readfromfolder(f);
			}
		}
			
			refine_maps();
			write_object_to_file(args[1]);
		
	}
		
	
	private static void Readfromfolder(File folder) {
		
		String foldername= folder.getName().toLowerCase();   
		File[] listOfFiles = folder.listFiles();
		
		if(foldername.equals("pos")){
			pos_map_length.put("pos", listOfFiles.length);
		}else if(foldername.equals("neg")){
			neg_map_length.put("neg", listOfFiles.length);
		}
		
		for (File file : listOfFiles) {
		    if (file.isFile()) {
		    	read_from_file(file,foldername);
		    } 
		}
	}
	
	
	
	private static void read_from_file(File filename, String foldername) {
		String line = null;
		try {
			// FileReader reads text files in the default encoding.
			FileReader fr = new FileReader(filename);
			BufferedReader br = new BufferedReader(fr);
			while ((line = br.readLine()) != null) {
				// System.out.println(line);
				String[] line_array = line.split(" +");
				for(String s: line_array){
					if(foldername.equals("neg")){
						if(neg_map.containsKey(s)){
							int value=neg_map.get(s);
							value+=1;
							neg_map.put(s, value);
						}else{
							neg_map.put(s, 1);
						}
						
					}else if(foldername.equals("pos")){
						if(pos_map.containsKey(s)){
							int value=pos_map.get(s);
							value+=1;
							pos_map.put(s, value);
						}else{
							pos_map.put(s, 1);
						}
					}
					
					if(vocabulary.containsKey(s)){
						int value=vocabulary.get(s);
						value+=1;
						vocabulary.put(s, value);
					}else{
						vocabulary.put(s, 1);
					}
					
					
				}
				
			}

			// close files.
			br.close();

		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file '" + filename + "'");
		} catch (IOException ex) {
			System.out.println("Error reading file '" + filename + "'");

		}
	}
	
	
	private static void write_object_to_file(String fname) {
		try {
			List myobject=new ArrayList();
			myobject.add(vocabulary);
			myobject.add(pos_map);
			myobject.add(neg_map);
			myobject.add(pos_map_length);
			myobject.add(neg_map_length);
			FileOutputStream fos = new FileOutputStream(fname);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(myobject);
			oos.close();
			fos.close();
			// System.out.printf("Serialized HashMap data is saved in hashmap.ser");
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

	}
	
private static void refine_maps() {
		
		for(Iterator<Map.Entry<String, Integer>> it = vocabulary.entrySet().iterator(); it.hasNext(); ) {
		      Map.Entry<String, Integer> entry = it.next();
		      if(entry.getValue()<5) {
		    	  if(pos_map.containsKey(entry.getKey())) {
		    		  pos_map.remove(entry.getKey());
		    	  }
		    	  if(neg_map.containsKey(entry.getKey())) {
		    		  neg_map.remove(entry.getKey());
		    	  }
		        it.remove();
		      }
		}
		
		
	}



}
