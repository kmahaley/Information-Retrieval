import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class modifiedtest {

	public static HashMap<String, Integer> vocabulary = new HashMap<String, Integer>();
	public static HashMap<String, Integer> positive = new HashMap<String, Integer>();
	public static HashMap<String, Integer> negative = new HashMap<String, Integer>();
	public static HashMap<String, Double> wordProbPos = new HashMap<String, Double>();
	public static HashMap<String, Double> wordProbNeg = new HashMap<String, Double>();
	public static HashMap<String, Double> wordProbPosNegRatio = new HashMap<String, Double>();
	public static HashMap<String, Double> wordProbNegPosRatio = new HashMap<String, Double>();
	public static double total_pos_docs;
	public static double total_neg_docs;
	public static String outputfile;
	public static boolean dev=false;

	public static double total_count_Vocab = 0.0;
	public static double total_count_positive = 0.0;
	public static double total_count_negative = 0.0;
	public static double positive_probability = 0.0;
	public static double negative_probability = 0.0;
	public static HashMap<String, ArrayList<String>> file_Class = new HashMap<String, ArrayList<String>>();
	public static HashMap<String, ArrayList<String>> Output_file_Class = new HashMap<String, ArrayList<String>>();

	public static void main(String args[]) throws IOException {
		read_from_input_file(args[0]);
		total_count_positive = calc_count(positive);
		total_count_negative = calc_count(negative);
		total_count_Vocab = vocabulary.entrySet().size();
		negative_probability = Math
				.log((total_neg_docs / (total_pos_docs + total_neg_docs)));
		positive_probability = Math
				.log((total_pos_docs / (total_pos_docs + total_neg_docs)));
		File testFiles = new File(args[1]);
		calcWordProb();
		outputfile=args[2];
		read_and_classify(testFiles);
		if(dev){
			calcCorrectness();
		}
		calcTopTerms();
		DisplayTop20();
	}
	
	
	public static void DisplayTop20(){
		TreeMap<String, Double> sortedPosNeg = sortbyvalue(wordProbPosNegRatio);
		int count=0;
		for(Entry<String, Double> entry : sortedPosNeg.entrySet()){
			count++;
			if(count>20)
				break;
			System.out.println(entry.getKey()+" => "+entry.getValue());
		}
		System.out.println("");
		TreeMap<String, Double> sortedNegPos = sortbyvalue(wordProbNegPosRatio);
		int count2=0;
		for(Entry<String, Double> entry : sortedNegPos.entrySet()){
			count2++;
			if(count2>20)
				break;
			System.out.println(entry.getKey()+" => "+entry.getValue());
		}
	}
	
	
	public static TreeMap<String, Double> sortbyvalue(Map<String, Double> map) {
		rankcomparator rc =  new rankcomparator(map);
		TreeMap<String,Double> sortedMap = new TreeMap<String,Double>(rc);
		sortedMap.putAll(map);
		return sortedMap;
	}

	private static void calcTopTerms() {
		Set<String> allWords = vocabulary.keySet();
		for (String s : allWords) {
			double logPos = 0.0;
			double logNeg = 0.0;
			if (wordProbPos.containsKey(s)) {
				logPos = wordProbPos.get(s);
				
			}
			 if (wordProbNeg.containsKey(s)) {
				logNeg = wordProbNeg.get(s);
			}else{
				if(!wordProbPos.containsKey(s)){
					System.out.println(s);
				}
			}
			wordProbPosNegRatio.put(s, logPos - logNeg);
			wordProbNegPosRatio.put(s, logNeg - logPos);
		}
	}
	
	private static void calcWordProb() {
		Set<String> allWords = vocabulary.keySet();
		for (String word : allWords) {
			if (positive.containsKey(word)) {
				double wordCountInClass = (double) positive.get(word);
				double prob = (wordCountInClass + 5.0)
						/ (total_count_positive + (5.0*total_count_Vocab));
				wordProbPos.put(word, Math.log(prob));
			}
			if (negative.containsKey(word)) {
				double wordCountInClass = (double) negative.get(word);
				double prob = (wordCountInClass + 5.0)
						/ (total_count_negative + (5.0*total_count_Vocab));
				wordProbNeg.put(word, Math.log(prob));
			}
		}
	}
	
	private static void read_and_classify(File file) throws IOException {
		if (!file.exists()) {
			System.out.println(file + " does not exist.");
		}
		for (File f : file.listFiles()) {
			if (f.isDirectory()) {
				dev=true;
				read_and_classify2(f, f.getName().toLowerCase());
			} else {
				readFile(f);
			}
		}
	}

	private static void read_and_classify2(File file, String className)
			throws IOException {
		for (File f : file.listFiles()) {
			if (className.equals("pos")) {
				className = "positive";
			} else if (className.equals("neg")) {
				className = "negative";
			}
			if (file_Class.containsKey(className)) {
				ArrayList<String> files = file_Class.get(className);
				files.add(f.getName().toLowerCase());
				file_Class.put(className, files);
			} else {
				ArrayList<String> files = new ArrayList<String>();
				files.add(f.getName().toLowerCase());
				file_Class.put(className, files);
			}
			readFile(f);

		}
	}

	private static void readFile(File f) throws IOException {
		String filename = f.getName().toLowerCase();
		ArrayList<String> words = new ArrayList<String>();

		FileReader fr = new FileReader(f);
		BufferedReader br = new BufferedReader(fr);
		String inputLine;
		//String query = br.readLine();
		while ((inputLine = br.readLine()) != null) {
			String info[] = inputLine.split(" ");
			for (String s : info) {
				words.add(s);
			}
		}

		fr.close();
		br.close();

		classify(filename, words);
	}

	private static void classify(String filename, ArrayList<String> words) throws IOException {
		Double probPos = 0.0;
		Double probNeg = 0.0;
		FileWriter fileWritter = new FileWriter(outputfile,true);
        BufferedWriter bufferWritter = new BufferedWriter(fileWritter);
        
		probPos = positive_probability + calcProb(words, "positive");
		probNeg = negative_probability + calcProb(words, "negative");
		String output;
		if (probPos > probNeg) {
			output = "positive";
		} else {
			output = "negative";
		}

		if (Output_file_Class.containsKey(output)) {
			ArrayList<String> files = Output_file_Class.get(output);
			files.add(filename);

			Output_file_Class.put(output, files);
		} else {
			ArrayList<String> files = new ArrayList<String>();
			files.add(filename);
	
			Output_file_Class.put(output, files);
		}

		System.out.println(String.format("%-22s %-25s %-37s %-35s","Filename: " + filename , " Prediction: " + output
				, " +veProbability: " + probPos,
				" -veProbability: " + probNeg));
		bufferWritter.write(String.format("%-22s %-25s %-37s %-35s \r \n","Filename: " + filename , " Prediction: " + output
				, " +veProbability: " + probPos,
				" -veProbability: " + probNeg));
        bufferWritter.close();
	}

	private static Double calcProb(ArrayList<String> words, String classType) {
		Double probSum = 0.0;
		for (String word : words) {
			Double wordProb = 0.0;
			if (classType.equals("positive")) {
				if (wordProbPos.containsKey(word)) {
					wordProb = wordProbPos.get(word);
				} else {
					wordProb = calcWordProbGivenClass(word, positive,
							total_count_positive);
					//wordProbPos.put(word, wordProb);

				}

			} else if (classType.equals("negative")) {
				if (wordProbNeg.containsKey(word)) {
					wordProb = wordProbNeg.get(word);
				} else {
					wordProb = calcWordProbGivenClass(word, negative,
							total_count_negative);
					//wordProbNeg.put(word, wordProb);
				}

			}
			probSum += wordProb;
		}
		
		return probSum;
	}

	private static Double calcWordProbGivenClass(String word,
			HashMap<String, Integer> classData, double totalCountclassData) {
		
		double wordCountInClass = 0.0;
		if (classData.containsKey(word)) {
			wordCountInClass = (double) classData.get(word);
		}
		double prob = (wordCountInClass + 5.0)
				/ (totalCountclassData + (5.0*total_count_Vocab));
		return Math.log(prob);
	}

	public static double calc_count(HashMap<String, Integer> map) {
		double count = 0.0;
		Collection<Integer> counts = map.values();
		for (int i : counts) {
			count += i;
			// System.out.println(count);
		}
		return count;
	}

	@SuppressWarnings("unchecked")
	private static void read_from_input_file(String objectfilename) {
		try {
			//String objectfilename = "objectfile.txt";
			FileInputStream fis = new FileInputStream(objectfilename);
			ObjectInputStream ois = new ObjectInputStream(fis);
			List readobject = (List) ois.readObject();

			vocabulary = (HashMap<String, Integer>) readobject.get(0);
			positive = (HashMap<String, Integer>) readobject.get(1);
			negative = (HashMap<String, Integer>) readobject.get(2);
			Map<String, Integer> pos_map_length = (Map<String, Integer>) readobject
					.get(3);
			Map<String, Integer> neg_map_length = (Map<String, Integer>) readobject
					.get(4);
			total_pos_docs = pos_map_length.get("pos");
			total_neg_docs = neg_map_length.get("neg");
			ois.close();
			// 'calculateBM25();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	private static void calcCorrectness() {
		ArrayList<String> positiveFileInput = file_Class.get("positive");
		ArrayList<String> positiveFileOutput = Output_file_Class
				.get("positive");
		double posCorrect = 0.0;
		for (String s : positiveFileInput) {

			if (positiveFileOutput.contains(s)) {
				posCorrect++;
			}
		}
		for (String s : positiveFileOutput) {
			System.out.println(s);
		}

		ArrayList<String> negativeFileInput = file_Class.get("negative");
		ArrayList<String> negativeFileOutput = Output_file_Class
				.get("negative");
		double negCorrect = 0.0;
		for (String s : negativeFileInput) {
			if (negativeFileOutput.contains(s)) {
				negCorrect++;
			}
		}
		System.out.println(positiveFileInput.size());
		System.out.println(negativeFileInput.size());
		System.out.println("percentage of positive correctly identified: "
				+ ((posCorrect / (double)positiveFileInput.size())*100)+"%");
		System.out.println("percentage of negative correctly identified: "
				+ ((negCorrect /(double) negativeFileInput.size())*100)+"%");
	}
}
